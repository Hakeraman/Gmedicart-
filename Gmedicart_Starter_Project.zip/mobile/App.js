import React, {useEffect,useMemo,useState} from 'react';
import {SafeAreaView,View,Text,TextInput,TouchableOpacity,ScrollView,StyleSheet,ActivityIndicator,Alert,Platform} from 'react-native';
import {StatusBar} from 'expo-status-bar';

const API = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000/api';
const money = n => '₹' + (n/100).toFixed(2);
export default function App() {
  const [products,setProducts] = useState([]);
  const [query,setQuery] = useState('');
  const [cart,setCart] = useState({});
  const [token,setToken] = useState('');
  const [user,setUser] = useState(null);
  const [email,setEmail] = useState('customer@gmedicart.local');
  const [password,setPassword] = useState('ChangeMe123!');
  const [name,setName] = useState('');
  const [address,setAddress] = useState('');
  const [busy,setBusy] = useState(false);
  const [orders,setOrders] = useState([]);
  const [tab,setTab] = useState('SHOP');
  const [payment,setPayment] = useState('COD');
  const [message,setMessage] = useState('');

  async function request(path, options={}) {
    const res = await fetch(API+path,{...options,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{}) ,...(options.headers||{})}});
    const data = await res.json().catch(()=>({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }
  async function loadProducts(q='') {
    try { setProducts(await request('/products'+(q?'?q='+encodeURIComponent(q):''))); }
    catch(e) { setMessage(e.message+' — check that the API server is running.'); }
  }
  useEffect(()=>{loadProducts();},[]);
  const cartItems = useMemo(()=>products.filter(p=>cart[p.id]).map(p=>({...p,quantity:cart[p.id]})),[products,cart]);
  const total = cartItems.reduce((s,p)=>s+p.price*p.quantity,0);
  async function login() {
    setBusy(true); setMessage('');
    try { const d=await request('/auth/login',{method:'POST',body:JSON.stringify({email,password})}); setToken(d.token); setUser(d.user); setTab('SHOP'); }
    catch(e){setMessage(e.message);} finally{setBusy(false);}
  }
  async function register() {
    setBusy(true); setMessage('');
    try { const d=await request('/auth/register',{method:'POST',body:JSON.stringify({name,email,password})}); setToken(d.token); setUser(d.user); }
    catch(e){setMessage(e.message);} finally{setBusy(false);}
  }
  async function checkout() {
    if (!token) {setMessage('Please log in before checkout.');setTab('ACCOUNT');return;}
    if (!address.trim()) {setMessage('Enter your full delivery address.');return;}
    setBusy(true);
    try {
      const d=await request('/orders',{method:'POST',body:JSON.stringify({items:cartItems.map(p=>({productId:p.id,quantity:p.quantity})),paymentMethod:payment,addressText:address})});
      setCart({}); setMessage(payment==='UPI'?'Order created. Complete payment using the configured Razorpay checkout integration.':'Order placed successfully with Cash on Delivery.');
      setTab('ORDERS'); await loadOrders();
    } catch(e){setMessage(e.message);} finally{setBusy(false);}
  }
  async function loadOrders(){try{setOrders(await request('/orders/mine'));}catch(e){setMessage(e.message);}}
  useEffect(()=>{if(tab==='ORDERS'&&token)loadOrders();},[tab,token]);
  function add(p){setCart(c=>({...c,[p.id]:Math.min((c[p.id]||0)+1,20)}));}
  function minus(p){setCart(c=>{const n={...c}; if((n[p.id]||0)<=1)delete n[p.id];else n[p.id]--;return n;});}
  const Button=({title,onPress,secondary=false})=><TouchableOpacity onPress={onPress} style={[styles.button,secondary&&styles.secondary]}><Text style={[styles.buttonText,secondary&&styles.secondaryText]}>{title}</Text></TouchableOpacity>;
  return <SafeAreaView style={styles.safe}><StatusBar style="dark"/><View style={styles.header}><View><Text style={styles.brand}>Gmedicart</Text><Text style={styles.tag}>Your health, delivered responsibly</Text></View><Text style={styles.cartCount}>Cart {cartItems.reduce((s,p)=>s+p.quantity,0)}</Text></View>
    <View style={styles.nav}>{['SHOP','CART','ORDERS','ACCOUNT'].map(t=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={[styles.navItem,tab===t&&styles.navActive]}><Text style={[styles.navText,tab===t&&styles.navTextActive]}>{t}</Text></TouchableOpacity>)}</View>
    {!!message&&<TouchableOpacity onPress={()=>setMessage('')} style={styles.notice}><Text style={styles.noticeText}>{message}  ×</Text></TouchableOpacity>}
    {tab==='SHOP'&&<><TextInput value={query} onChangeText={v=>{setQuery(v);loadProducts(v);}} placeholder="Search medicines and health products" style={styles.search}/><ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>Shop health essentials</Text>{products.map(p=><View key={p.id} style={styles.product}><View style={{flex:1}}><Text style={styles.productName}>{p.name}</Text><Text style={styles.muted}>{p.category}</Text><Text style={styles.description}>{p.description}</Text><Text style={styles.price}>{money(p.price)}</Text>{p.requiresPrescription&&<Text style={styles.warning}>Prescription required — online checkout is disabled until verification workflow is completed.</Text>}</View><Button title={cart[p.id]?'Add another':'Add to cart'} onPress={()=>add(p)}/></View>)}</ScrollView></>}
    {tab==='CART'&&<ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>Your cart</Text>{cartItems.length===0?<Text style={styles.muted}>Your cart is empty.</Text>:cartItems.map(p=><View style={styles.cartRow} key={p.id}><View style={{flex:1}}><Text style={styles.productName}>{p.name}</Text><Text>{money(p.price)} × {p.quantity}</Text></View><View style={styles.qty}><Button title="−" secondary onPress={()=>minus(p)}/><Text>{p.quantity}</Text><Button title="+" onPress={()=>add(p)}/></View></View>)}<Text style={styles.total}>Total: {money(total)}</Text><Text style={styles.label}>Delivery address</Text><TextInput value={address} onChangeText={setAddress} placeholder="House, street, area, city, state, PIN" multiline style={styles.input}/><Text style={styles.label}>Payment</Text><View style={styles.payRow}><Button title="Cash on Delivery" secondary={payment!=='COD'} onPress={()=>setPayment('COD')}/><Button title="UPI" secondary={payment!=='UPI'} onPress={()=>setPayment('UPI')}/></View><Text style={styles.muted}>UPI checkout requires Razorpay credentials and a completed checkout SDK integration.</Text><Button title={busy?'Please wait…':'Place order'} onPress={checkout}/></ScrollView>}
    {tab==='ORDERS'&&<ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>My orders</Text>{!token?<Text>Please log in to view your orders.</Text>:orders.map(o=><View key={o.id} style={styles.product}><Text style={styles.productName}>Order {o.id.slice(-8)}</Text><Text>{o.status} · {o.paymentMethod} · {money(o.total)}</Text><Text style={styles.muted}>{new Date(o.createdAt).toLocaleString()}</Text></View>)}</ScrollView>}
    {tab==='ACCOUNT'&&<ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>{user?'Your account':'Login / Register'}</Text>{user?<><Text style={styles.productName}>{user.name}</Text><Text>{user.email}</Text><Button title="Log out" onPress={()=>{setUser(null);setToken('');setOrders([]);}}/></>:<><TextInput value={name} onChangeText={setName} placeholder="Name (for registration)" style={styles.input}/><TextInput value={email} onChangeText={setEmail} placeholder="Email" autoCapitalize="none" keyboardType="email-address" style={styles.input}/><TextInput value={password} onChangeText={setPassword} placeholder="Password (8+ characters)" secureTextEntry style={styles.input}/><Button title={busy?'Please wait…':'Login'} onPress={login}/><Button title="Create account" secondary onPress={register}/><Text style={styles.muted}>Demo: customer@gmedicart.local / ChangeMe123!</Text></>}</ScrollView>}
    <Text style={styles.footer}>For emergencies, contact local emergency services. Medicines are dispensed only after required pharmacist and prescription checks.</Text>
  </SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#f5f8f7'},header:{padding:18,backgroundColor:'#fff',flexDirection:'row',justifyContent:'space-between',alignItems:'center'},brand:{fontSize:26,fontWeight:'800',color:'#087f5b'},tag:{fontSize:12,color:'#68736f'},cartCount:{fontWeight:'700',color:'#087f5b'},nav:{flexDirection:'row',backgroundColor:'#fff',borderTopWidth:1,borderColor:'#e7eeeb'},navItem:{flex:1,padding:13,alignItems:'center'},navActive:{borderBottomWidth:3,borderColor:'#087f5b'},navText:{fontSize:11,color:'#68736f',fontWeight:'700'},navTextActive:{color:'#087f5b'},content:{padding:16,paddingBottom:40},heading:{fontSize:22,fontWeight:'800',marginBottom:16,color:'#172b25'},search:{margin:14,padding:13,borderRadius:12,backgroundColor:'#fff',borderWidth:1,borderColor:'#dce6e1'},product:{backgroundColor:'#fff',padding:15,borderRadius:14,marginBottom:12,borderWidth:1,borderColor:'#e5eeea',gap:6},productName:{fontSize:16,fontWeight:'700',color:'#20332c'},muted:{color:'#718079',fontSize:12,marginTop:4},description:{color:'#52615b',fontSize:13,marginTop:6},price:{fontSize:17,fontWeight:'800',color:'#087f5b',marginTop:8},button:{backgroundColor:'#087f5b',paddingHorizontal:14,paddingVertical:11,borderRadius:10,alignItems:'center',marginTop:8},buttonText:{color:'#fff',fontWeight:'700'},secondary:{backgroundColor:'#e4f2ec'},secondaryText:{color:'#087f5b'},cartRow:{backgroundColor:'#fff',padding:14,borderRadius:12,marginBottom:10,flexDirection:'row',alignItems:'center'},qty:{flexDirection:'row',alignItems:'center',gap:10},total:{fontSize:20,fontWeight:'800',textAlign:'right',marginVertical:18},label:{fontWeight:'700',marginTop:12,marginBottom:6},input:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dce6e1',borderRadius:10,padding:13,marginBottom:10,minHeight:46},payRow:{flexDirection:'row',gap:10,justifyContent:'flex-start'},notice:{backgroundColor:'#fff3cd',padding:12,marginHorizontal:14,marginTop:8,borderRadius:10},noticeText:{color:'#725400'},warning:{color:'#9b4a00',fontSize:12,marginTop:6},footer:{fontSize:10,color:'#8a9690',textAlign:'center',padding:10},});
