import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Razorpay from 'razorpay';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

const prisma = new PrismaClient();
const app = express();
app.use(cors({origin: process.env.CLIENT_ORIGIN?.split(',') || true}));
app.use(express.json({limit:'1mb'}));
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error('JWT_SECRET is required');

function tokenFor(user) {
  return jwt.sign({sub:user.id, role:user.role, email:user.email}, JWT_SECRET, {expiresIn:'7d'});
}
async function auth(req,res,next) {
  try {
    const raw = req.headers.authorization?.replace(/^Bearer\\s+/i,'');
    if (!raw) return res.status(401).json({error:'Login required'});
    req.user = jwt.verify(raw, JWT_SECRET);
    next();
  } catch { return res.status(401).json({error:'Invalid or expired session'}); }
}
function admin(req,res,next) {
  if (!['ADMIN','PHARMACIST'].includes(req.user?.role)) return res.status(403).json({error:'Admin/pharmacist access required'});
  next();
}
app.get('/api/health', (_req,res)=>res.json({ok:true,app:'Gmedicart API'}));

app.post('/api/auth/register', async (req,res) => {
  const schema = z.object({name:z.string().min(2),email:z.string().email(),password:z.string().min(8),phone:z.string().optional()});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Enter a valid name, email and password (8+ characters)'});
  try {
    const data = parsed.data;
    const user = await prisma.user.create({data:{...data,passwordHash:await bcrypt.hash(data.password,12)},select:{id:true,name:true,email:true,role:true}});
    res.status(201).json({user,token:tokenFor(user)});
  } catch { res.status(409).json({error:'Email is already registered'}); }
});
app.post('/api/auth/login', async (req,res) => {
  const {email,password} = req.body || {};
  const user = await prisma.user.findUnique({where:{email}});
  if (!user || !(await bcrypt.compare(password || '',user.passwordHash))) return res.status(401).json({error:'Incorrect email or password'});
  const safe = {id:user.id,name:user.name,email:user.email,role:user.role};
  res.json({user:safe,token:tokenFor(safe)});
});
app.get('/api/products', async (req,res) => {
  const q = String(req.query.q || '');
  const products = await prisma.product.findMany({where:{active:true, ...(q?{OR:[{name:{contains:q,mode:'insensitive'}},{category:{contains:q,mode:'insensitive'}}]}:{})},orderBy:{name:'asc'}});
  res.json(products);
});
app.post('/api/admin/products', auth, admin, async (req,res) => {
  const schema = z.object({name:z.string().min(2),description:z.string(),category:z.string(),price:z.number().int().positive(),stock:z.number().int().min(0),requiresPrescription:z.boolean().default(false)});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Invalid product details'});
  res.status(201).json(await prisma.product.create({data:parsed.data}));
});
app.get('/api/admin/orders', auth, admin, async (_req,res) => {
  res.json(await prisma.order.findMany({include:{user:{select:{name:true,email:true}},items:{include:{product:true}}},orderBy:{createdAt:'desc'}}));
});
app.patch('/api/admin/orders/:id/status', auth, admin, async (req,res) => {
  const allowed = ['PRESCRIPTION_REVIEW','PROCESSING','SHIPPED','DELIVERED','CANCELLED'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({error:'Invalid status'});
  res.json(await prisma.order.update({where:{id:req.params.id},data:{status:req.body.status}}));
});
app.post('/api/orders', auth, async (req,res) => {
  const schema = z.object({items:z.array(z.object({productId:z.string(),quantity:z.number().int().min(1).max(20)})).min(1),paymentMethod:z.enum(['UPI','COD']),addressText:z.string().min(8)});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Invalid order details'});
  if (parsed.data.paymentMethod === 'UPI' && (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET)) return res.status(501).json({error:'UPI gateway is not configured. Configure Razorpay keys before enabling UPI checkout.'});
  try {
    const result = await prisma.$transaction(async tx => {
      let total = 0; const rows = [];
      for (const item of parsed.data.items) {
        const p = await tx.product.findUnique({where:{id:item.productId}});
        if (!p || !p.active || p.stock < item.quantity) throw new Error(`Unavailable stock: ${p?.name || 'product'}`);
        // Prescription-required items are blocked until a reviewed prescription workflow is implemented.
        if (p.requiresPrescription) throw new Error(`Prescription verification is required for ${p.name}. Please contact the pharmacy.`);
        total += p.price * item.quantity;
        rows.push({productId:p.id,quantity:item.quantity,unitPrice:p.price});
        await tx.product.update({where:{id:p.id},data:{stock:{decrement:item.quantity}}});
      }
      return tx.order.create({data:{userId:req.user.sub,total,paymentMethod:parsed.data.paymentMethod,addressText:parsed.data.addressText,items:{create:rows}} ,include:{items:{include:{product:true}}}});
    });
    if (parsed.data.paymentMethod === 'UPI') {
      const razorpay = new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
      const rpOrder = await razorpay.orders.create({amount:result.total,currency:'INR',receipt:result.id});
      const updated = await prisma.order.update({where:{id:result.id},data:{razorpayOrderId:rpOrder.id}});
      return res.status(201).json({order:updated,razorpay:{id:rpOrder.id,amount:rpOrder.amount,currency:rpOrder.currency,keyId:process.env.RAZORPAY_KEY_ID}});
    }
    res.status(201).json({order:result});
  } catch(e) { res.status(400).json({error:e.message || 'Could not create order'}); }
});
app.get('/api/orders/mine', auth, async (req,res) => {
  res.json(await prisma.order.findMany({where:{userId:req.user.sub},include:{items:{include:{product:true}}},orderBy:{createdAt:'desc'}}));
});
app.post('/api/prescriptions', auth, async (req,res) => {
  const {fileUrl} = req.body || {};
  if (typeof fileUrl !== 'string' || !/^https:\\/\\//.test(fileUrl)) return res.status(400).json({error:'Upload the prescription to approved secure storage and provide its HTTPS URL'});
  const p = await prisma.prescription.create({data:{userId:req.user.sub,fileUrl}});
  res.status(201).json(p);
});
app.get('/api/admin/prescriptions', auth, admin, async (_req,res) => res.json(await prisma.prescription.findMany({include:{user:{select:{name:true,email:true}}},orderBy:{createdAt:'asc'}})));
app.patch('/api/admin/prescriptions/:id', auth, admin, async (req,res) => {
  const {status,reviewNote} = req.body || {};
  if (!['APPROVED','REJECTED'].includes(status)) return res.status(400).json({error:'Status must be APPROVED or REJECTED'});
  res.json(await prisma.prescription.update({where:{id:req.params.id},data:{status,reviewNote:String(reviewNote || '').slice(0,500)}}));
});

app.listen(PORT,()=>console.log(`Gmedicart API listening on ${PORT}`));
