import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();
async function main() {
  const adminHash = await bcrypt.hash('ChangeMe123!', 12);
  const customerHash = await bcrypt.hash('ChangeMe123!', 12);
  await prisma.user.upsert({where:{email:'admin@gmedicart.local'},update:{},create:{name:'Gmedicart Admin',email:'admin@gmedicart.local',passwordHash:adminHash,role:'ADMIN'}});
  await prisma.user.upsert({where:{email:'customer@gmedicart.local'},update:{},create:{name:'Demo Customer',email:'customer@gmedicart.local',passwordHash:customerHash}});
  const products = [
    {name:'Digital Thermometer',description:'Reusable digital thermometer for temperature measurement.',category:'Health devices',price:19900,stock:30},
    {name:'First Aid Kit',description:'Basic household first-aid supplies. Check contents before use.',category:'First aid',price:49900,stock:15},
    {name:'ORS Sachets',description:'Oral rehydration salts. Use as directed on the pack.',category:'Wellness',price:2500,stock:100},
    {name:'Vitamin C Tablets',description:'Example catalogue item. Follow label directions and pharmacist advice.',category:'Vitamins',price:12000,stock:40}
  ];
  for (const p of products) await prisma.product.create({data:p});
}
main().finally(()=>prisma.$disconnect());
