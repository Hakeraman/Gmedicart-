# Gmedicart — Online Pharmacy Starter

A cross-platform Expo app (Android + Web) with an Express API and PostgreSQL/Prisma backend.

## Important before launch
This is a development starter, not a legally approved pharmacy platform. In India, dispense/sell medicines only through a properly licensed pharmacy, with pharmacist oversight and prescription verification where required. Do not list or sell prescription-only medicines until your licensing, pharmacist workflow, recordkeeping, and applicable state/central requirements have been reviewed. This starter does not diagnose or recommend medicines.

## Requirements
- Node.js 20+
- npm
- PostgreSQL 15+
- Expo Go for Android testing (or Android Studio for a native build)

## 1. Start the API
```bash
cd server
cp .env.example .env
# Edit DATABASE_URL and JWT_SECRET in .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```
API runs at http://localhost:4000. For a physical Android phone, set `EXPO_PUBLIC_API_URL` to your computer's LAN IP, e.g. `http://192.168.1.10:4000/api` (phone and computer must share Wi-Fi).

## 2. Start Android + Web app
In another terminal:
```bash
cd mobile
cp .env.example .env
# Set EXPO_PUBLIC_API_URL; for web local development use http://localhost:4000/api
npm install
npx expo start
```
- Press `w` to open web.
- Scan the QR code with Expo Go to run Android.
- For web production build: `npx expo export --platform web`.

## Demo accounts
Seed creates:
- Admin: `admin@gmedicart.local` / `ChangeMe123!`
- Customer: `customer@gmedicart.local` / `ChangeMe123!`

Change these credentials and remove demo accounts before deployment.

## Payments
The checkout supports COD immediately. UPI is represented by a Razorpay order flow on the server. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in `server/.env`; add the official Razorpay Checkout SDK to the app and implement its native/web-specific UI before accepting real payments. Never trust a payment success message from the client: verify the Razorpay signature on the server and update the order only after verification. Do not store card/UPI PIN data.

## Production checklist
- Deploy API behind HTTPS and use a managed PostgreSQL database.
- Set strong secrets; configure CORS to your real domains.
- Add email/SMS OTP, password reset, rate limiting, audit logs, backups and monitoring.
- Add image storage (S3-compatible) and malware scanning for prescription uploads.
- Build pharmacist/admin prescription review with approve/reject reasons and immutable audit history.
- Add stock reservation, tax/invoice rules, delivery zones, refunds and cancellation policies.
- Integrate Razorpay Checkout properly and verify signatures server-side.
- Obtain legal review and required pharmacy licences before accepting orders.
